import React from "react";

function Orderlist() {
    return (<ol>
    <li>Sweta</li>
    <li>Paul</li>
    <li>thapa</li>
    <li>thapa technical</li>
  </ol>);
}
export default Orderlist;
import React, { useEffect } from "react";


const Statewise =() => {

  const getCovidData = async () => {
    const res = await fetch( 'https://api.covid19india.org/data.json');
    const actualData = await res.json();
    console.log(actualData);
  }
  useEffect(() => {
      getCovidData();
  },[]);

     return(
         <>
         <h1> india covid-19 dashboard</h1>
         <div className="container-fluid mt-5">
         <div className="main-heading">
           <h className="mb-5"> <span className="font-weight-bold">INDIA</span>covid-19 dashboard</h>
         </div>
         <div className="table-responsive">
         <table className="table table-hover">

         </table>
         </div>
         </div>
         </>
     )
};

export default Statewise;
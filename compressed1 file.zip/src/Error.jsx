import React from "react";
import { NavLink } from "react-router-dom";

const Error = () => {
     return (
     <>
     <div className="setStyle2">
     <h1> 404 Error page</h1>
     <p>Sorry, this page doesnot exist</p>
     <NavLink to="/"> Go back</NavLink>
     </div>
     </>
     );
};
export default Error;
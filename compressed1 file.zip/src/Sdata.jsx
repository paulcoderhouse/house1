const Sdata = [
    {
        id:1,
        imgsrc:"https://wallpapercave.com/wp/wp4056410.jpg",
        sname:"DARK",
        title:" Netflix Original series",
        link:"https://www.netflix.com/in/title/80990668?source=35",
    },
    {
        id:2,
        // imgsrc:"https://www.hitc.com/static/uploads/hitcn/1816/extracurricular_netflix_780_1544944.jpg",
        imgsrc:"https://wallpapercave.com/wp/wp4056410.jpg",
        sname:"Extra curricular",
        title:" Netflix Original series",
        link:"https://www.netflix.com/in/title/80990668?source=35",
    },
    {
        id:3,
        imgsrc:"https://wallpapercave.com/wp/wp1917154.jpg",
        sname:"stranger things",
        title:" Netflix Original series",
        link:"https://www.netflix.com/in/title/80990668?source=35",
    },
    {
        id:4,
        imgsrc:"https://images.justwatch.com/poster/8589251/s592",
        sname:"the vampire diaries",
        title:"Azon Original series",
        link:"https://www.netflix.com/in/title/80990668?source=35",
    },  
      
    
];

export default Sdata;
//import { Switch, Route } from "@material-ui/core";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import React from "react";
import Home from "./Home";
import Abouts from "./Abouts";
import Service from "./Service";
import Contacts from "./Contacts";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Switch, Route, Redirect } from "react-router-dom";


const App4 = () => {
    return(
        <>
        <Navbar/>
        <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/abouts" component={Abouts} />
        <Route exact path="/service" component={Service} />
        <Route exact path="/contacts" component={Contacts} />   
        <Redirect to="/" />
        </Switch>
        <Footer/>
        </>
    );
}

export default App4;
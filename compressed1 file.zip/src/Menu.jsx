import React from "react";
import { Link, NavLink } from "react-router-dom";

const Menu = () => {

    return (
    <>
      <Link to="/"> About us</Link>
      <Link to="/contact">Contact us</Link>
    <br/>
      <NavLink exact activeClassName="active_class" to="/">
       About us
       </NavLink>
      <NavLink exact activeClassName="active_class" to="/contact">
      Contact us
      </NavLink>
      <NavLink exact activeClassName="active_class" to="/search">
        Search
      </NavLink>
      <NavLink exact activeClassName="active_class" to="/user/sweta/paul">
       User
       </NavLink>
       <br/>
      

    </>
    )
}

export default Menu;





// (function () {
//   try {
//     throw new Error();
//   } catch (x) {
//     var x=1, y=2;
//     console.log(x);
//   }
//   console.log(x);
//   console.log(y);
// })
//  ();






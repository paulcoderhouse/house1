import React, { useRef } from "react";
import { FaHeart } from "react-icons/fa";
import { MdPlaylistAdd } from "react-icons/md";
import { FaShareAlt } from "react-icons/fa";

const Bottom_bar = () => {
     const loveBtn = useRef();
   function changeColor() { 
            if(loveBtn.current.style.color === "black"){
                loveBtn.current.style.color = "red"
            }else {
                loveBtn.current.style.color = "black"
            }
        }
    return(
        <>
            <div className="bottom_bar">
                      <button className="heart_btn" onClick={changeColor}><FaHeart ref={loveBtn}/></button>
                      <button className="addlist_btn"><MdPlaylistAdd/></button>
                      <button className="share_btn"><FaShareAlt/></button>

            </div>
        </>
    )
}
export default Bottom_bar;
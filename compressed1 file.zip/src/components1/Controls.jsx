
import React, {useEffect, useRef, useState} from "react";
import { FaBackward, FaForward, FaRandom, FaPlay, FaRedoAlt, FaSyncAlt, FaVolumeUp, FaPause, FaGlasses, } from "react-icons/fa";

function Controls  (props) {

         const audioRef = useRef();
         const progressBar = useRef();
         const animationRef = useRef();
        
    
        
        let [isPlaying, setIsPlaying] = useState(false);
        let [duration, setDuration1] = useState(0);
        let [currentTime, setCurrentTime] = useState(0);
        
        useEffect (() => {
          const secs = Math.floor(audioRef.current.duration);
          setDuration1 (secs);
          progressBar.current.max = secs;
        },[audioRef?.current?.loadedmetadata, audioRef?.current?.readyState]);
         
       
         const calculateTime = (secs) => {
             let minutes = Math.floor(secs / 60);
             let returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
             let seconds = Math.floor(secs % 60);
            let returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
            return `${returnedMinutes}: ${returnedSeconds}`;
         }
        const  whilePlaying = () => {
            progressBar.current.value = audioRef.current.currentTime;
            let progress_time = (progressBar.current.value/duration) * 100;
            progressBar.current.style.setProperty("--seek-before-width", `${progress_time}%`);
            setCurrentTime(progressBar.current.value);
            animationRef.current = requestAnimationFrame(whilePlaying)  ;
        }

        const changeRange = () => {
            audioRef.current.currentTime = progressBar.current.value;
            let progress_time = (progressBar.current.value/duration) * 100;
            progressBar.current.style.setProperty("--seek-before-width", `${progress_time}%`);
            setCurrentTime(progressBar.current.value);
        }



//  function getRandomNumber(min,max) {
//        let step1 = max-min+1;
//        let step2 = Math.random() * step1;
//        let result = Math.floor(step2) + min;
//        return result;
    
//     }
//     function random() {
//        let randomIndex = getRandomNumber(0, props.songs.length - 1);
//        props.currentSongIndex = randomIndex;
//        props.songs[props.currentSongIndex];
//        audioRef.current.play();
//     }

        const togglePlayPause = () => { 
            setIsPlaying(!isPlaying);
            if(isPlaying === false) {
                audioRef.current.play();
                animationRef.current = requestAnimationFrame(whilePlaying)
            }else {
                audioRef.current.pause();
                cancelAnimationFrame(animationRef.current);
            }
        }



const skipSong = (forwards = true) => {
    if(forwards) {
        props.setCurrentSongIndex(() => {
            let temp = props.currentSongIndex;
            temp++;

            if(temp > props.songs.length - 1) {
                temp = 0;
            }
            return temp;
        })
        togglePlayPause();
        debugger;
    }
    else {
        props.setCurrentSongIndex(() => {
            let temp = props.currentSongIndex;
            temp--;

            if(temp < 0) {
                temp = props.songs.length - 1
            }
            return temp;
        })
        //  setIsPlaying(!isPlaying);
        //  audioRef.current.play();
    }
}

function loop (){
   audioRef.current.currentTime = 0;
   audioRef.current.play();
}

// function loopForRepeat() {
//    if(audioRef.current.loop){
//        audioRef.current.loop = false;
//       `$("#repeat").attr("src", "./music/imagesong2.mp3")`;
//    }else{
//        audioRef.current.loop = true;
//       `$("#repeat").attr("src", "./music/imagesong3.mp3")`;
//    }  
// }

 const myRef1 = useRef();
 const myRef2= useRef();
 const volume1 = () => {
    myRef1.current.classList.toggle("active");
    myRef2.current.classList.toggle("active");
    audioRef.current.volume = myRef2.current.value;
}


    return (
        <>
        <div className="controls">
        
        <audio ref={audioRef} src={props.songs[props.currentSongIndex].src}></audio>
         <div className="music_controls">
        <FaRandom  className="control_btn"/>
        
        <FaRedoAlt className="control_btn" onClick={loop}/>
        <div className="play_pause">
            <button className="skip_btn"><FaBackward onClick={() => skipSong(false)}/></button>
             <button className="play_btn"  onClick={() => togglePlayPause()}>   
            {isPlaying === false ? <FaPlay/> : <FaPause/>} </button>
            <button className="skip_btn" ><FaForward onClick={() => skipSong()}/></button>
        </div>
        <FaSyncAlt className="control_btn" id="repeat"/> 
        <FaVolumeUp className="volumeBtn" id="volumebtn" ref={myRef1} onClick={() => volume1()}/>
        <input type="range" id="volume-slider" className="volumeSlider" max="1" value="1" step="0.1" ref={myRef2}/>  
        </div>
        <div className="progress-area" id="progress-area" onChange={() => changeRange()}>
            {/* <div className="progress-bar" id="progress-bar" ref = {progressBar} >
            </div> */}
            <input  type = "range" className="progressBar" id="progress-bar" ref = {progressBar} />
            <div className="timer">
                <span className="current-time"> {calculateTime(currentTime)}</span>
                <span className="duration">{(duration && !isNaN(duration)) && calculateTime(duration)} </span>

            </div>
        </div>
        </div>
        </>
    )

}
export default Controls;
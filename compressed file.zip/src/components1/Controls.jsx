
import React, {useEffect, useRef, useState} from "react";
import { FaBackward, FaForward, FaRandom, FaPlay, FaRedoAlt, FaSyncAlt, FaVolumeUp, FaPause, } from "react-icons/fa";

function Controls  (props) {

    // const audioRef = useRef()

    // let isPlaying = false;
    //   function playMusic() {
    //     isPlaying = true;
    //     audioRef.current.play();
    // }
    //   function pauseMusic () {
    //  isPlaying = false;
    //  audioRef.current.pause();
    
    // }
    // function clickHandler () {
    //  (isPlaying) ? pauseMusic() : playMusic()
    
    // }

    //     const nextSong = () => {
    //         props.currnrtSongIndex = (props.currentSongIndex + 1 ) % props.songs.length;
    //         props.songs[props.currentSongIndex] 
    //         playMusic();  
    //    }

        // const prevSong = () => {
        //     songIndex = (songIndex - 1 + songs.length) % songs.length;
        //    (songs[songIndex]) 
        // }

         const audioRef = useRef()
         const progressBar = useRef()
        let [isPlaying, setIsPlaying] = useState(false);
        let [duration, setDuration1] = useState(0);
        let [currentTime, setCurrentTime] = useState(0);
        
        useEffect (() => {
          const secs = Math.floor(audioRef.current.duration);
          setDuration1 (secs);
          progressBar.current.max = secs;
        },[audioRef?.current?.loadedmetadata, audioRef?.current?.readyState]);
         
       
         const calculateTime = (secs) => {
             let minutes = Math.floor(secs / 60);
             let returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
             let seconds = Math.floor(secs % 60);
            let returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
            return `${returnedMinutes}: ${returnedSeconds}`;
         }

        const changeRange = () => {
            audioRef.current.currentTime = progressBar.current.value;
            progressBar.current.style.setProperty("width" ,`${progressBar.current.value / duration * 100}%`)
            setCurrentTime(progressBar.current.value);
        }
        const togglePlayPause = () => {
           
            setIsPlaying(!isPlaying);
            if(isPlaying === false) {
                audioRef.current.play();
            }else {
                audioRef.current.pause();
            }
        }


const skipSong = (forwards = true) => {
    if(forwards) {
        props.setCurrentSongIndex(() => {
            let temp = props.currentSongIndex;
            temp++;

            if(temp > props.songs.length - 1) {
                temp = 0;
            }
            return temp;
        })
         setIsPlaying =(!isPlaying);
         audioRef.current.play();
       
    }else {
        props.setCurrentSongIndex(() => {
            let temp = props.currentSongIndex;
            temp--;

            if(temp < 0) {
                temp = props.songs.length - 1
            }
            return temp;
        })
        //  setIsPlaying(!isPlaying);
        //  audioRef.current.play();
    }
}

function loop (){
   audioRef.current.currentTime = 0;
   audioRef.current.play();
}

// function loopForRepeat() {
//    if(audioRef.current.loop){
//        audioRef.current.loop = false;
//       `$("#repeat").attr("src", "./music/imagesong2.mp3")`;
//    }else{
//        audioRef.current.loop = true;
//       `$("#repeat").attr("src", "./music/imagesong3.mp3")`;
//    }  
// }
   
    return (
        <>
        <div className="controls">
        
        <audio ref={audioRef} src={props.songs[props.currentSongIndex].src}></audio>
         <div className="music_controls">
        <FaRandom  className="control_btn"/>
        <FaRedoAlt className="control_btn" onClick={loop}/>
        <div className="play_pause">
            <button className="skip_btn"><FaBackward onClick={() => skipSong(false)}/></button>
             <button className="play_btn"  onClick={() => togglePlayPause()}>   
            {isPlaying === false ? <FaPlay/> : <FaPause/>} </button>
            <button className="skip_btn" ><FaForward onClick={() => skipSong()}/></button>
        </div>
        <FaSyncAlt className="control_btn" id="repeat" /> 
         <input type="range" id="volume-slider" className="volume-slider" max="1" value="1" step="0.1"/>  
        <FaVolumeUp className="control_btn"/>
        </div>
        <div className="progress-area" id="progress-area" onChange={() => changeRange()}>
            <div className="progress-bar" id="progress-bar" ref = {progressBar} >
            </div>
            <div className="timer">
                <span className="current-time"> {calculateTime(currentTime)}</span>
                <span className="duration">{(duration && !isNaN(duration)) && calculateTime(duration)} </span>

            </div>
        </div>
        </div>
        </>
    )

}
export default Controls;
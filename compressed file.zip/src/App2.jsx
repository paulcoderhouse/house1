// import React from "react";
// import {add,sub,div,mult} from "./App";
// function App2() {
//     return (
//    <>
//    <ul>
//      <li>sum of two no is {add(50,5)}</li>
//      <li>sub of two no is {sub(30,3)}</li>
//      <li>div of two no is {div(12,7)}</li>
//      <li>mult of two no is {mult(10,3)}</li>
//    </ul>
//    </>
//     );
// }
// export default App2;


// import React from "react";
// import SlotM from "./Slotmach";

// const SlotM = (props) => {
//     // let x = "smile";
//     // let y = "smile";
//     // let z = "smilenot";

//     let x = props.x;
//     let y = props.y;
//     let z = props.z;

//     if(x === y && y === z){
//         return( 
//             <div className="slot_inner">
//             <h1> {x} {y} {z}</h1>
//             <h1> This is matching</h1>
//             <hr/>
//             </div>
//         ); 
//     }else {
//         return( 
//             <div>
//                 <h1> {x} {y} {z}</h1>
//                 <h1>This is not matching</h1>
//                 <hr/>
//             </div>
//         );
//     }
// };

// const App2 = () => {
//     return(
//         <>
//         <h1 className="heading_style">
//             Welcome to{ " "} <span style={{fontWeight: "bold"}}> Slot machine game</span>
//         </h1>
//         <div className="slot_machine">
//         <SlotM  x = "smile" y = "smile" z = "smile"/>
//         <SlotM  x = "smile" y = "smile" z = "not smile"/>
//         <SlotM  x = "apple" y ="banana" z = "apple" />
//         <SlotM  x = "love" y = "love" z = "love" />
//         </div>
//         </>
//     );
// };
// export default App2;


// import React, { useState } from "react";



// const App2 = () => {
//     const state = useState();
//     //console.log(state);//

//     const [count,setCount] = useState(100)

// const IncNum = () => {
//     setCount(count - 10);
//    // console.log("clicked" + count++);
// };
//     return(
//         <>
//         <h1>{count}</h1>
//         <button onClick={IncNum}> Click Me</button>
//         </>
//     );
// };

// export default App2;




// import React from "react";
// import { useState } from "react/cjs/react.development";

// let currDate = new Date();
// currDate = currDate.toLocaleTimeString();

// const state = useState();
// const [currTime,setDate] = useState(currDate)

// const IncDate = () => {
//    return (setDate(currTime + currTime.getSeconds)
//    );
// }
// const App2 = () => {
    
// let currTime = new Date().toLocaleTimeString();

// const state = useState();
// const [ctime,setCtime] = useState(currTime);

// const IncDate = () => {
//     currTime = new Date().toLocaleTimeString();
//    return (setCtime(currTime)
//    );
// }
//     return(
//         <>
//         <h1>{ctime}</h1>
//         <button onClick={ IncDate}> Get Time</button>
//         </>
//     );
// }

// export default App2;


//creating a digital clock
// import React from "react";
// import { useState } from "react/cjs/react.development";

// const App2 = () => {
// let time = new Date().toLocaleTimeString();
// const [ctime,setCtime] = useState(time);

// const UpdateTime = () => {
//     time = new Date().toLocaleTimeString();
//     setCtime(time);
// };
//  setInterval(UpdateTime,1000);
//     return(
//         <h1>{ctime}</h1>
//     );
// };
// export default App2;

// Handling events in ReactJs
//  import React from "react";
// import { useState } from "react/cjs/react.development";

//  const App2 = () => {
//      const purple = "#8e44ad";
//      const[bg,setBg] = useState(purple);
//      const[name,setName] = useState("Click me");
     
//     const bgChange = () => {
//         console.log("clicked");
//         let newBg ="#34495e";
//         setBg(newBg);
//         setName("ouch..");
//     };
//     const bgBack = () => {
//         setBg(purple);
//         setName("uffff");
//     };

//     return(
//         <div style={{ backgroundColor:bg }}>
//         <button onClick={bgChange} onDoubleClick={bgBack}>{name}</button>
//       </div>
//       );
//      };
// export default App2;

// import React from "react";
// import { useState } from "react/cjs/react.development";
// const App2 = () => {
//     const[name,setName] = useState("");
//      const[lastName,setName1] = useState("");
//      const[fullName, setFullName] = useState();
//      const[lastNameNew, setLastNameNew] = useState();

//     const inputEvent = (event) => {
//         console.log(event.target.value);
//         setName(event.target.value); 
//     };
//      const inputEventTwo = (event) => {
//          console.log(event.target.value);
//        setName1(event.target.value); 
//     };
//     const onSubmits = (event) => {
//         event.preventDefault();
//         setFullName(name);
//         setLastNameNew(lastName);
//     };
    
//     return(
//     <>
//     <form onSubmit={onSubmits}>
//     <div>
//         <h1> Hello {fullName} {lastNameNew}</h1>
//         <input type = "text" placeholder="Enter your name"  onChange={inputEvent} value={name}/>
       
    
//     <br/>
    
//         <input type = "text" placeholder="Enter your last Name"  onChange={inputEventTwo} value={lastNameNew}/>
//         <button type = "submit">Submit me 👍</button>
//     </div>
//     </form>
//      </>
//     );
// }
// export default App2;       

// import React from "react";
// import { useState } from "react/cjs/react.development";

// const App2 = () => {
//     const [fullName,setFullName] = useState({
//         fname: "",
//         lname: "",
//         email: "",
//         phone: "",
//     });
//     const inputEvent = (event) => {
//         console.log(event.target.value);
//         console.log(event.target.name);
        
        // const value = event.target.value;
        // const name = event.target.name;
        // const{name, value} = event.target;

        //  setFullName((preValue) => {
        //      console.log(preValue);

        //      return {
        //          ...preValue,
        //          [name] : value,
        //      };
            //  if(name === "fName") {
            //      return {
            //          fname: value,
            //          lname: preValue.lname,
            //          email: preValue.email,
            //          phone: preValue.phone,
            //      };
            //  }else if (name === "lName") {
            //      return{
            //         fname: preValue.fname,
            //         lname: value,
            //         email: preValue.email,
            //         phone: preValue.phone,
            //      };
            //  }else if (name === "email") {
            //     return{
            //        fname: preValue.fname,
            //        lname: preValue.lname,
            //        email: value,
            //        phone: preValue.phone,
            //     };
            // }else if (name === "phone") {
            //     return{
            //        fname: preValue.fname,
            //        lname: preValue.lname,
            //        email: preValue.email,
            //        phone: value,
            //     };
            // }
//          });
//     };
//     const onSubmits = (event) => {
//         event.preventDefault();
//         alert("form submitted");
//     };
//     return(
//     <>
//     <form onSubmit = {onSubmits}>
//         <div>
//             <h1> Hello {fullName.fname} {fullName.lname} </h1>
//             <p> {fullName.email}  </p>
//            <p> {fullName.phone} </p>
//             <input type ="text" placeholder="Enter your name" 
//             name="fname" onChange={inputEvent} value={fullName.fname}/> 
//          <br/><br/>
//          <input type ="text" placeholder="Enter your Last name"
//           name="lname" onChange={inputEvent} value={fullName.lname}/> 
//           <br/><br/>
//           <input type ="email" placeholder="Enter your email" 
//             name="email" onChange={inputEvent} value={fullName.email} autoComplete="off"/> 
//             <br/><br/>
//             <input type ="number" placeholder="Enter your phonenumber" 
//             name="phone" onChange={inputEvent} value={fullName.phone}/> 
//             <br/><br/>
//          <button type="submit">Submit Me</button>
//         </div>
//     </form>
//    </>
//     );
// };
// export default App2;


//project:to do list
// import React from "react";
// import { useState } from "react/cjs/react.development";
// import ToDOLists from "./ToDoLists";

// const App2 = () => {
//    const[list, setList] = useState("");
//    const[items, setItems] = useState([]);

//    const inputEvent = (event) => {
//     setList(event.target.value) ;
//    };
//    const listOfItems = () => {
//        setItems((oldItems) => {
//         return [...oldItems, list];
//    });
//    setList("");
// };
// const deleteItems = (id) => {

//     setItems((oldItems) => {
//         return oldItems.filter((arrElem,index) => {
//         return index !== id;
//         });
//     });
// };
//     return(
//         <> 
//     <div className="main-div">
//     <div className="center-div">
//     <br/>
//     <h1>To do list</h1>
//     <br/>
//     <input type="text" placeholder="Add items" 
//     onChange={inputEvent} value={list}></input>
//     <button  onClick={listOfItems}> + </button>

//     <ol>
//    {items.map((itemval,index)=>{
//      return <ToDOLists
//           key={index}
//           id={index}
//           text={itemval}
//           onSelect={deleteItems}
//       />;
//     })}
//     </ol>

//     </div>

//    </div>
//     </>
//     );
// }
// export default App2;


// import React, { useState } from "react";
// import AddIcon from '@material-ui/icons/Add';
// import RemoveIcon from '@material-ui/icons/Remove';
// import Button from '@material-ui/core/Button';


// const App2 = () => {

//     const [count,setCount] = useState(0);

// const incNum = () => {
//     setCount(count + 1);

// };
// const decNum = () => {
//     if(count>0) {
//     setCount(count -1);
//     }else{
//         alert("soryy,zero limit reached")
//         setCount(0);
//     }

// };
//     return(
//         <>
//         <h1>{count}  </h1>
//         <Button onClick={incNum}><AddIcon/>
//        </Button>
//         <Button onClick={decNum}> <RemoveIcon/></Button>
//         </>
//     );
// };

// export default App2;


//Project ToDo list using material-ui
// import React, { useState } from "react";
// import Button from '@material-ui/core/Button';
// import AddIcon from '@material-ui/icons/Add';
// import ListCom from "./ListCom";

// const App2 = () => {
// const[item,setItem]=useState("");
// const[newItem, setNewItem] = useState([]);

// const itemEvent=(event) => {
//     setItem(event.target.value);
// };
// const listOfItems=() => {
//     setNewItem((preValue) => {
//         return[...preValue, item];
//     });
//     setItem("");
// }

//     return (
//        <> 
//        <div className="main-div">
//            <div className ="center-div">
//               <br/> <h1>To Do list</h1><br/>
//               <input type="text" placeholder="Add items" onChange={itemEvent} value={item}/>
//               <Button className="newBtn" onClick={listOfItems}>       
//               <AddIcon/> </Button>
//             <br/>
//               <ol>
//                   {newItem.map((val,index) => {
//                   return <ListCom text={val} key={index}/>;
//                   })}
//               </ol>
//               <br/>
//            </div>
//        </div>
//        </>
//     );
// }
// export default App2;



//Context Api and createContext
// import React, { createContext } from "react";
// import ComponentA from "./ComponentA";

// const FirstName = createContext();
// const LastName = createContext();
// const App2 = () => {
//    return(
//        <> 
//        <FirstName.Provider value={"Tumpi"}>
//        <LastName.Provider value={"Paul"}>
//        <ComponentA/>
//        </LastName.Provider>
//         </FirstName.Provider>
//        </>
//    );
// };
// export default App2;
// export{FirstName,LastName};

//useEffect
// import React, { useEffect, useState } from "react";


// const App2 = () => {
//    const[num,setNum] =useState(0);
//    const[nums,setNums]=useState(0);

    
//    useEffect(() => {
//         alert (`you clicked me ${num} times`)
//     },[num])
// //   document.title = `you clicked me ${num} times`;
// //    });

//    return (
//        <>
//        <button onClick={() => {
//            setNum(num+1)
//        }}>Click me {num}</button>

//        <button onClick={() => {
//            setNums(nums+1)
//        }}>Click me {nums}</button>
//      </>
//    )
//  };
// export default App2;

//Covid-19 dashboard
// import React from "react";
// import CompA from "./CompA";
// import Statewise from "./components/stateWiseData/Statewise";

// const App2 = () => {
//     return(
//         <>
//          <CompA/>   
//         </>

//     )
// }

// export default App2;

import React from "react";
 import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
// import {Route, Switch, Redirect} from "react-router-dom";
// import About from "./About";
// import Contact from "./Contact";
// import Error from "./Error";
// import Menu from "./Menu";
// import User from "./User";
// import Search from "./Search";

// const App2 = () => {

//     const Name = () => {
//         return <h1> Hello, I am Name page</h1>
//     };
//    return (
//        <>
//        <Menu/>
//        <Switch>
//            <Route  exact path="/" component={() => <About  mame="About"/>}/>
//            <Route exact path="/contact" component={ Contact} />
//            <Route  path="/contact/name" component={ Name} />
//            <Route exact path="/search" component={ Search} />
//            <Route path="/user/:fname/:lname" component={ User }/>
//            {/* <Route component={ Error }/> */}
//            <Redirect to="/" />
//        </Switch>
//            {/* <About/>
//            <Contact></Contact> */}
//        </>
//    )
// };


// const App2 = () => {
//     return(
//         <>
//         <div className="text-center">
//         <h1>Welcome</h1>
//         <div class="card" style={{width: "18rem"}}>
//   <img src="https://picsum.photos/200/200" class="card-img-top" alt="..." />
//   <div class="card-body">
//     <h5 class="card-title">Card title</h5>
//     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
//     <a href="#" class="btn btn-outline-success">Go somewhere</a>
//   </div>
// </div>
//         <button className="btn btn-outline-success"> Welcome to future</button>
//         </div>
//       </>
//     );
// }
// export default App2;

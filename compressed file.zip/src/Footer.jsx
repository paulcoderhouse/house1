import React from "react";

const Footer = () => {
    return (
        <>
            <footer className="bg-light text-center">
                <p>©️ 2020 ThapaTechical. All rights reserved | Terms and conditions</p>
            </footer>
        </>
    )
};

export default Footer;
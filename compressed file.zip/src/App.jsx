// import React from "react";
// import Heading  from "./Heading";
// import Para from "./Para";
// import Orderlist from "./Orderlist";

// function App() {
//     return (
//         <>
//         <Heading/>
//         <Para/>
//         <Orderlist/>
//         </>
//     );
// }
// export default App;


// import React from "react";

// function App () {
//         let currDate = new Date(2020,8,9,20);
//          currDate = currDate.getHours();
//          let greeting = "";
//           let cssStyle = {};
        
//          if(currDate>=1 && currDate < 12) {
//            greeting = "Good morning";
//            cssStyle.color = "green";
//         }else if (currDate>=12 && currDate<19){
//            greeting = "Good afternoon";
//            cssStyle.color = "orange";
//         }else if(currDate>=20 && currDate<24) {
//           greeting = "Goodninght";
//           cssStyle.color = "purple";
//         }
        
//         return( 
//             <>
//           <div>
//           <h1>Hello sir,<span style = {cssStyle} > {greeting} </span></h1>
//           </div>
//           </>
//         )
    
// }

// export default App;


// function add(a,b){
//     let sum = a+b;
//     return sum ;
// }
// function sub(a,b){
//     let sub = a-b;
//     return sub ;
// }
// function div(a,b){
//   let div = a/b;
//   div = div.toFixed(3);
//   return div ;
// }
// function mult(a,b){
//   let mult = a*b;
//   return mult;
// }

// export {add,sub,div,mult};

import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

const App = () => {
    return (
        <>
        <h1>Welcome to my channel</h1>
        <button className="btn btn-success">Thapatechnical</button>
        <div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">@</span>
  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2"/>
  <span class="input-group-text" id="basic-addon2">@example.com</span>
</div>

<label for="basic-url" class="form-label">Your vanity URL</label>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon3">https://example.com/users/</span>
  <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3"/>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">$</span>
  <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)"/>
  <span class="input-group-text">.00</span>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Username" aria-label="Username"/>
  <span class="input-group-text">@</span>
  <input type="text" class="form-control" placeholder="Server" aria-label="Server"/>
</div>

<div class="input-group">
  <span class="input-group-text">With textarea</span>
  <textarea class="form-control" aria-label="With textarea"></textarea>
</div>
        </>
    );
}
export default App;
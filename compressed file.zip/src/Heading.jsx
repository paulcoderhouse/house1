import React from 'react';

// function Heading() {
//    return <h1>My name is Sweta Paul</h1>;
// }

const Heading = (props) => {
   return <h3 className="card_title">{props.sname}</h3>
}

export default Heading ;
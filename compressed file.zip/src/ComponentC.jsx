import React from "react";
import { FirstName, LastName } from "./App2";

const ComponentC = () => {
return(
    <>
   <FirstName.Consumer>{(fname) => {
    return (
        <LastName.Consumer>
            {(lname) => {
                <h1>My name is {lname} </h1>;
            return <h1>My name is {fname}{lname} </h1>;
            }}
        </LastName.Consumer>
    );  
   }}
  </FirstName.Consumer>
</>
);
};
export default ComponentC;
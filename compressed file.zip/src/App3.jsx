import React from "react";
import Netflix from "./Netflix";
import Amazon from "./Amazon";
import Sdata from "./Sdata";
import Card from "./Cards";


 const App3 = () => (
   <>
   <h1 className="heading_style">List of top 5 Netflix Series in 2020</h1>
    
     {Sdata.map( (val) => {
       return(
      <Card
      key={val.id}
     imgsrc={val.imgsrc}
     sname= {val.sname}
     title= {val.title}
     link= {val.link}
     />
     );
    })}
   </>
 );
 export default App3;

// const favSeries = "netflix";
 
// const FavS = () => {
//     if(favSeries === "netflix") {
//         return <Netflix/>;
//     }else{
//         return <Amazon/>;
//     }
// };

// const App3 = () => (
//     <>
//     <h1 className="heading_style">List of top 5 Netflix series in 2020</h1>
//     {/* {favSeries === "netflix" ? <Netflix/> : <Amazon/>} */}
//     <FavS/>
//     </>
// );
//export default App3;
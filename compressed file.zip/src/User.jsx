import React from "react";
import {useParams, useLocation, useHistory} from "react-router-dom";

 const User = () => {
    const  {fname, lname} = useParams();
    const location=useLocation();
    const history=useHistory();
    console.log(location);
     return(
       <>
         <h1>User {fname} {lname} page</h1>
          <p>my current location is {location.pathname}</p> 
          {location.pathname === `/user/sweta/paul`? (
            <button onClick={() => history.goBack()}>go back</button>)
          :null}
         </>
     );
 };

// const User = ({match}) => {
//    return <h1> User {match.params.name} page</h1>;
// };
export default User;
